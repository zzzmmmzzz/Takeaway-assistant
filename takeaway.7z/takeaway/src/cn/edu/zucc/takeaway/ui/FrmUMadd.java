package cn.edu.zucc.takeaway.ui;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Dialog;
import java.awt.FlowLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import cn.edu.zucc.takeaway.takeawayUtil;
import cn.edu.zucc.takeaway.model.Beanuser;
import cn.edu.zucc.takeaway.util.BaseException;

public class FrmUMadd extends JDialog implements ActionListener{
	private JPanel toolBar = new JPanel();
	private JPanel workPane = new JPanel();
	private Button btnOk = new Button("ע��");
	private Button btnCancel = new Button("ȡ��");
	private JComboBox jcb=null;
	
	private JLabel labelMerchantid = new JLabel("�̼ұ�ţ�");
	private JLabel labelMerchantName = new JLabel("�̼�����");
	private JLabel labelMerchantStar = new JLabel("�̼��Ǽ���");
	private JLabel labelMerchantAvg = new JLabel("�˾����ѣ�");
	private JLabel labelMerchantall = new JLabel("��������");
	
	private JTextField edtMerchantid = new JTextField(20);
	private JTextField edtMerchantName = new JTextField(20);
	private JTextField edtMerchantStar = new JTextField(20);
	private JTextField edtMerchantAvg = new JTextField(20);
	private JTextField edtMerchantall = new JTextField(20);
	
	public FrmUMadd(Frmmainuser f, String s, boolean b) {
		super(f, s, b);
		toolBar.setLayout(new FlowLayout(FlowLayout.RIGHT));
		toolBar.add(this.btnOk);
		toolBar.add(btnCancel);
		this.getContentPane().add(toolBar, BorderLayout.SOUTH);
		workPane.add(labelMerchantid);
		workPane.add(edtMerchantid);
		workPane.add(labelMerchantName);
		workPane.add(edtMerchantName);
		workPane.add(labelMerchantStar);
		workPane.add(edtMerchantStar);
		workPane.add(labelMerchantAvg);
		workPane.add(edtMerchantAvg);
		workPane.add(labelMerchantall);
		workPane.add(edtMerchantall);
		
		this.getContentPane().add(workPane, BorderLayout.CENTER);
		this.setSize(260, 500);
		double width = Toolkit.getDefaultToolkit().getScreenSize().getWidth();
		double height = Toolkit.getDefaultToolkit().getScreenSize().getHeight();
		this.setLocation((int) (width - this.getWidth()) / 2,
				(int) (height - this.getHeight()) / 2);

		this.validate();

		
		this.btnCancel.addActionListener(this);
		this.btnOk.addActionListener(this);
	}
	
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==this.btnCancel)
			this.setVisible(false);
		else if(e.getSource()==this.btnOk){
			
				/*try {
					new Frmmainuser();
				}catch(Exception ex) {
					JOptionPane.showMessageDialog(null, ex.getMessage(),"����",JOptionPane.ERROR_MESSAGE);
					return;
				}*/
			}
			
		}
			
		
	
}
