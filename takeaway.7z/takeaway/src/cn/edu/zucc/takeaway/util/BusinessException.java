package cn.edu.zucc.takeaway.util;

import cn.edu.zucc.takeaway.util.BaseException;

public class BusinessException extends BaseException {
	public BusinessException(String msg){
		super(msg);
	}
}
