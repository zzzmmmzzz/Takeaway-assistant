package cn.edu.zucc.takeaway.model;

import java.util.Date;

public class Beanrider {
  private String rider_id;
  private String rider_name;
  private Date rider_workdate;
  private int rider_identity;

public String getRider_id() {
	return rider_id;
}
public void setRider_id(String rider_id) {
	this.rider_id = rider_id;
}
public String getRider_name() {
	return rider_name;
}
public void setRider_name(String rider_name) {
	this.rider_name = rider_name;
}
public Date getRider_workdate() {
	return rider_workdate;
}
public void setRider_workdate(Date rider_workdate) {
	this.rider_workdate = rider_workdate;
}
public int getRider_identity() {
	return rider_identity;
}
public void setRider_identity(int rider_identity) {
	this.rider_identity = rider_identity;
}
  
}
