package cn.edu.zucc.takeaway.model;

public class Beangoods_details {
  private String goods_id;
  private String categories_id;
  private String goods_name;
  private float goods_price;
  private float goods_reduce;

public String getGoods_id() {
	return goods_id;
}
public void setGoods_id(String goods_id) {
	this.goods_id = goods_id;
}
public String getCategories_id() {
	return categories_id;
}
public void setCategories_id(String categories_id) {
	this.categories_id = categories_id;
}
public String getGoods_name() {
	return goods_name;
}
public void setGoods_name(String goods_name) {
	this.goods_name = goods_name;
}
public float getGoods_price() {
	return goods_price;
}
public void setGoods_price(float goods_price) {
	this.goods_price = goods_price;
}
public float getGoods_reduce() {
	return goods_reduce;
}
public void setGoods_reduce(float goods_reduce) {
	this.goods_reduce = goods_reduce;
}
  
}
