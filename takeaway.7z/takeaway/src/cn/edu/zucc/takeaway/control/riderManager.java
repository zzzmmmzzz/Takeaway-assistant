package cn.edu.zucc.takeaway.control;

import cn.edu.zucc.takeaway.itf.IriderManager;
import cn.edu.zucc.takeaway.itf.IuserManager;

public class riderManager implements IriderManager{

}
