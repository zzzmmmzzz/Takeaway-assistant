package cn.edu.zucc.takeaway.itf;

public interface IMerchantManager {

}
