package cn.edu.zucc.takeaway;

import java.io.IOException;

import cn.edu.zucc.takeaway.ui.FrmMain;

public class takeawayStarter {
	public static void main(String[] args) throws IOException{
		// TODO Auto-generated method stub
		new FrmMain();
	}

}
